<?php

namespace App\Http\Controllers;

use App\Http\Requests\SurveyRequest;
use App\Models\Jawaban;
use App\Models\Option;
use App\Models\Pertanyaan;
use App\Models\Survey;
use Illuminate\Http\Request;

class FormSurveyController extends Controller
{
    public function index()
    {
        $pertanyaan = Pertanyaan::all();
        $option = Option::all();
        return view('pages.user.survey', [
            'option' => $option,
            'pertanyaan' => $pertanyaan
        ]);
    }

    public function store(SurveyRequest $request)
    {
        $data = $request->all();

        $survey = Survey::create([
            'nama' => $data['nama'],
            'jenis_kelamin' => $data['jenis_kelamin'],
            'pekerjaan' => $data['pekerjaan'],
            'email' => $data['email'],
            'usulan' => $data['usulan'],
        ]);

        $pertanyaan = Pertanyaan::all();
        foreach ($pertanyaan as $item) {
            $jawaban = Jawaban::create([
                'survey_id' => $survey->id,
                'pertanyaans_id' => $item->id,
                'options_id' => $data['answer-' . $item->id],
            ]);
        }

        return redirect()->route('home');
    }
}
